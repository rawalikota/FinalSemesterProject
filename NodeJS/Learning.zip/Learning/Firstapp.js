const fs =require('fs');
fs.writeFileSync('Hello.txt','Hello from Node.JS');
//console.log("Hello from Node.js");