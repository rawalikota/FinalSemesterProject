const path=require('path');

//const http=require('http'); //not required when 
const express =require('express');
const bodyParser=require('body-parser');

const eapp=express();

const adminRoutes=require('./routes/admin');
const shopRoutes=require('./routes/shop');


eapp.use(bodyParser.urlencoded({extended:false}));
eapp.use(express.static(path.join(__dirname, 'public')));

eapp.use('/admin',adminRoutes);
eapp.use(shopRoutes);

eapp.use((req,res,next)=>{
    res.status(404).sendFile(path.join(__dirname, 'views', 'error.html'));
});

//const server=http.createServer(eapp);
//server.listen(3000);
eapp.listen(3000); //creates the server and listens the port

